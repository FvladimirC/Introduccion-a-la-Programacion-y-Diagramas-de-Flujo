# Usando un bucle for con la función range()
for numero in range(1, 11):
  print(numero)