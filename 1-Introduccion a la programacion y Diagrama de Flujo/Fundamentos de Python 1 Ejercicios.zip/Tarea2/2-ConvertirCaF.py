#Convierte grados Celsius a Fahrenheit. Pide al usuario que ingrese la
#temperatura en Celsius y muestra el resultado en Fahrenheit.

# Solicitar al usuario la temperatura en grados Celsius
celsius = float(input("Ingrese la temperatura en grados Celsius: "))

# Convertir a Fahrenheit usando la fórmula
fahrenheit = (celsius * 9/5) + 32

# Mostrar el resultado
print(celsius," grados Celsius equivalen a ", fahrenheit," grados Fahrenheit.")
