# Solicitar la edad al usuario
edad = int(input("Ingrese su edad: "))

# Determinar si es mayor de edad
if edad >= 18:
    print("Eres mayor de edad.")
else:
    print("Eres menor de edad.")