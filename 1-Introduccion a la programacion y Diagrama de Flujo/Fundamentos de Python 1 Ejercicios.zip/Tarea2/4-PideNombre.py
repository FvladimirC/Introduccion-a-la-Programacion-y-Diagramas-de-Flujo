# Solicitar el nombre del usuario
nombre = input("Ingrese su nombre: ")

# Mostrar mensaje de bienvenida
print("¡Bienvenido ", nombre," Espero que tengas un excelente día!.")