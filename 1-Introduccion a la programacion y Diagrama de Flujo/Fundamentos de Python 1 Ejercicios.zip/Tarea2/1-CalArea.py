

#Calcula el área de un rectángulo. Pide al usuario que ingrese el largo y el
#ancho, y luego muestra el área.

# Solicitar las dimensiones al usuario
largo = float(input("Ingrese el largo del rectángulo: "))
ancho = float(input("Ingrese el ancho del rectángulo: "))

# Calcular el área
area = largo * ancho

# Mostrar el área
print("El área del rectángulo es: ",area)


