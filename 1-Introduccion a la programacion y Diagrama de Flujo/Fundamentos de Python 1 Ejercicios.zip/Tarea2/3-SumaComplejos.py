#Suma dos números complejos. Define dos números complejos y muestra el
#resultado de su suma.

# Definir dos números complejos
num1 = complex(3, 4)  # 3 + 4j
num2 = complex(1, 2)  # 1 + 2j

# Sumar los números complejos
resultado = num1 + num2

# Mostrar el resultado
print("La suma de ",num1, " y ",num2, "es: " ,resultado)