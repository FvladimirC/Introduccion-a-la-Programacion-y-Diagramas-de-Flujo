# Solicitar un número al usuario
numero = int(input("Ingrese un número: "))

# Determinar si el número es par o impar
if numero % 2 == 0:
    print("El número es par.")
else:
    print("El número es impar.")