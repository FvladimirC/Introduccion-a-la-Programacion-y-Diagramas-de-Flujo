# Inicializar la suma
suma = 0

# Usar un bucle para pedir números al usuario
while True:
    numero = int(input("Ingrese un número a sumar (Poner '0' para finalizar la Suma): "))
    if numero == 0:  # Salir del bucle si el usuario ingresa 0
        break
    suma += numero  # Agregar el número a la suma

# Mostrar el resultado final
print("La suma de los números ingresados es: ",suma)