#Escribe un programa que pida al usuario dos números y muestre la suma,
#resta, multiplicación y división de esos números.

# Solicitar al usuario dos números
num1 = float(input("Ingrese el primer número: "))
num2 = float(input("Ingrese el segundo número: "))

# Realizar operaciones matemáticas
suma = num1 + num2
resta = num1 - num2
multiplicacion = num1 * num2

# Verificar si el divisor es diferente de cero para evitar errores
if num2 != 0:
    division = num1 / num2
else:
    division = "Error: No se puede dividir entre cero"

# Mostrar los resultados
print("Suma: ",suma)
print("Resta: ",resta)
print("Multiplicación: ",multiplicacion)
print("División: ",division)