

#1-Crea una tupla con los nombres de 5 países y muestra el tercer elemento.

# Crear una tupla con 5 nombres de países
paises = ("USA", "Brasil", "Republica Dominicana", "México", "Colombia")

# Mostrar el tercer elemento (índice 2, ya que los índices comienzan desde 0)
print(paises[2])