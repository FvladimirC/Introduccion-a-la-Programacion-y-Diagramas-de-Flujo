

#4-Crear una calculadora usando bibliotecas


import math

def menu():
    print("\n===== CALCULADORA EN CONSOLA =====")
    print("1. Sumar")
    print("2. Restar")
    print("3. Multiplicar")
    print("4. Dividir")
    print("5. Potencia")
    print("6. Raíz cuadrada")
    print("7. Seno")
    print("8. Coseno")
    print("9. Tangente")
    print("10. Factorial")
    print("0. Salir")

def pedir_numero(mensaje="Ingresa un número: "):
    while True:
        try:
            return float(input(mensaje))
        except ValueError:
            print("❌ Entrada inválida. Intenta de nuevo.")

def calculadora():
    while True:
        menu()
        opcion = input("Selecciona una opción: ")

        if opcion == '0':
            print("👋 ¡Hasta luego!")
            break
        elif opcion in ['1', '2', '3', '4', '5']:
            num1 = pedir_numero("Primer número: ")
            num2 = pedir_numero("Segundo número: ")

            if opcion == '1':
                print(f"✅ Resultado: {num1 + num2}")
            elif opcion == '2':
                print(f"✅ Resultado: {num1 - num2}")
            elif opcion == '3':
                print(f"✅ Resultado: {num1 * num2}")
            elif opcion == '4':
                if num2 != 0:
                    print(f"✅ Resultado: {num1 / num2}")
                else:
                    print("❌ Error: División por cero.")
            elif opcion == '5':
                print(f"✅ Resultado: {math.pow(num1, num2)}")
        elif opcion == '6':
            num = pedir_numero("Número: ")
            if num >= 0:
                print(f"✅ Resultado: {math.sqrt(num)}")
            else:
                print("❌ Error: No se puede sacar raíz cuadrada de un número negativo.")
        elif opcion in ['7', '8', '9']:
            angulo = pedir_numero("Ángulo en grados: ")
            rad = math.radians(angulo)
            if opcion == '7':
                print(f"✅ Seno: {math.sin(rad)}")
            elif opcion == '8':
                print(f"✅ Coseno: {math.cos(rad)}")
            elif opcion == '9':
                print(f"✅ Tangente: {math.tan(rad)}")
        elif opcion == '10':
            num = pedir_numero("Número entero: ")
            if num >= 0 and num.is_integer():
                print(f"✅ Resultado: {math.factorial(int(num))}")
            else:
                print("❌ Error: El factorial solo se aplica a enteros no negativos.")
        else:
            print("❌ Opción inválida.")

# Ejecutar calculadora
calculadora()
