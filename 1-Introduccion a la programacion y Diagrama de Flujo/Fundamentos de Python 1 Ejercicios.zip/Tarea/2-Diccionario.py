

#2-Crea un diccionario con información de una persona (nombre, edad, ciudad) y muestra la edad.

# Crear un diccionario con información de una persona
persona = {
    "nombre": "Freddy",
    "edad": 30,
    "ciudad": "Santo Domingo"
}

# Mostrar la edad de la persona accediendo al valor por su clave
edad_persona = persona["edad"]
print(edad_persona)